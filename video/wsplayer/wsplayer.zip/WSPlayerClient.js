function WSPlayerClient (player, _index) {

  var index = 0;
console.log(_index)
  if (_index) {
    index = _index;
  }
  var aPlayer = player;

  function send (data) {
    let message = JSON.stringify(data);
    window.parent.postMessage(message, "*");
  }

  function initProxy () {
    aPlayer.onStoping = function () {
      send({ index: index, command: "onStoping" });
    }
    aPlayer.getPosition = function (value) {
      send({ index: index, command: "getPosition", value: value });
    }
    aPlayer.getTimer = function (value) {
      send({ index: index, command: "getTimer", value: value });
    }
    aPlayer.onPlaying = function () {
      send({ index: index, command: "onPlaying" });
    }
    aPlayer.onButtonClicked = function (value) {
      send({ index: index, command: "onButtonClicked", value: value });
    }
    aPlayer.onViewerDoubleClicked = function () {
      send({ index: index, command: "onViewerDoubleClicked" });
    }
    aPlayer.onViewerClicked = function () {
      send({ index: index, command: "onViewerClicked" });
    }
    aPlayer.onStatusChanged = function (value) {
      send({ index: index, command: "onStatusChanged", value: value });
    }
    aPlayer.onCapturePicture = function (data) {
      let str = Uint8ArrayToString(data);
      send({ index: index, command: "onCapturePicture", data: str });
    }
    aPlayer.onRuleStateChanged = function (value) {
      send({ index: index, command: "onRuleStateChanged", value: value })
    }
  }
  function Uint8ArrayToString (fileData) {
    var dataString = "";
    for (var i = 0; i < fileData.length; i++) {
      dataString += String.fromCharCode(fileData[i]);
    }

    return dataString

  }
  window.addEventListener("message", function (e) {
    console.log("wsplayer.html message:", e);
    if (!aPlayer) return;
    if (e && e.data) {
      try {
        let data = JSON.parse(e.data)

        switch (data.command) {
          case "stop":
            aPlayer.stop();
            break;
          case "play":
            aPlayer.play();
            break;
          case "seek":
            aPlayer.seek(data.value);
            break;
          case "fast":
            aPlayer.fast();
            break;
          case "slow":
            aPlayer.slow();
            break;
          case "capturePicture":
            aPlayer.capturePicture();
            break;
          case "getCapturePictureData":
            let promise = aPlayer.getCapturePictureData();
            promise.then((data) => {
              //let str = Uint8ArrayToString(data);
              send({ index: index, command: "onCapturePicture", data: Array.from(data) });
            })

            break;
          case "pause":
            aPlayer.pause();
            break;
          case "speedResume":
            aPlayer.speedResume();
            break;
          case "resume":
            aPlayer.resume();
            break;
          case "frame":
            aPlayer.frame();
            break;
          case "fullScreen":
            aPlayer.fullScreen();
            break;
          case "resize":
            aPlayer.resize(data.width, data.height);
            break;
          case "fullExit":
            aPlayer.fullExit();
            break;
          case "download":
            aPlayer.download(data.filename, data.type);
            break;
          case "openSound":
            aPlayer.openSound();
            break;
          case "closeSound":
            aPlayer.closeSound();
            break;
          case "getVolume":
            aPlayer.getVolume();
            break;
          case "setVolume":
            aPlayer.setVolume(data.value);
            break;
          case "changeRuleState":
            aPlayer.changeRuleState(data.value)
            break;
          case "buttonClick":
            break;
          default:
            break;

        }
      } catch (error) {

      }
    }
  });

  initProxy();
}